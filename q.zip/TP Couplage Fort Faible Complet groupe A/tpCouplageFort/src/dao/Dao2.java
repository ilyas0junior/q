package dao;

public class Dao2 {
	public double getData() {
		System.out.println("Version capture");
		double data=150;
		return data;
	}
}
