package metier;

import dao.Dao2;

public class Metier {

	private  Dao2  dao=null;
	
	
	

	// setter
	public void setDao(Dao2 dao) {
		this.dao = dao;
	}
	
	// contructeur
//       public Metier(Dao1 dao) {
//		       //super();
//		    this.dao = dao;
//	       }


	public double calculer() {
		double data=dao.getData();
		double res=data*5;
		return res;
	}
	
}
