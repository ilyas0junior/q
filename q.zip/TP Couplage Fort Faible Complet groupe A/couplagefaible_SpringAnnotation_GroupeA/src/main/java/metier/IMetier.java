package metier;

public interface IMetier {
	
	public double calculer();

}
