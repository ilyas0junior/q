package presentation;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import dao.DaoImpl1;
import dao.DaoImpl2;
import dao.IDao;
import metier.IMetier;
import metier.MetierImpl1;

@Controller
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext("dao","metier");
		IMetier metier=(IMetier) ctx.getBean("metier");
		System.out.println("le r�sultat est : "+metier.calculer());
		
	}

}
