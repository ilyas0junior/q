package org.example.entity;

public enum TypeProduit {
    Cosmitique, Neutritif
}
