package ma.poly.composite;

import java.util.ArrayList;
import java.util.List;

public class Dossier extends Composant {
    private List<Composant> composants;
    public Dossier(String nom) {
        super(nom);
        composants=new ArrayList<>();
    }
    @Override
    public void afficher() {
    String tab="";
        for (int i = 0; i < niveau; i++) {
            tab=tab+"\t";
        }
        System.out.println(tab+"Dossier : "+nom);
        for (Composant c:composants)
            c.afficher();
    }
    public void addComposant(Composant composant){
        composant.niveau=this.niveau+1;
        composants.add(composant);
    }

}
