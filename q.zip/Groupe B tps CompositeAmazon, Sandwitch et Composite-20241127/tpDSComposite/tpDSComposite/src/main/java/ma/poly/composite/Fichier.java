package ma.poly.composite;

public class Fichier extends Composant{


    public Fichier(String nom) {
        super(nom);
    }
    @Override
    public void afficher() {
        String tab="";
        for (int i = 0; i <niveau ; i++) {
            tab=tab + "\t";
        }
        System.out.println(tab+"Fichier : "+nom);

    }
}
