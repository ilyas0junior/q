package ma.poly.tpDecorator.decorator;

import ma.poly.tpDecorator.Sandwitch;

public class Fritte extends SandwitchDecorator{
    public Fritte(Sandwitch sandwitch) {
        super(sandwitch);
    }

    @Override
    public double getCout() {
        return sandwitch.getCout()  +5;
    }

    public String getDescription(){

        return sandwitch.getDescription()+" Au Fritte";
    }
}
