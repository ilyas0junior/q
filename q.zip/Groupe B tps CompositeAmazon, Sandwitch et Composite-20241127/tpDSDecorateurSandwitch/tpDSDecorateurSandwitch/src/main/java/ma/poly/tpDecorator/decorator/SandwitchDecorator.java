package ma.poly.tpDecorator.decorator;

import ma.poly.tpDecorator.Sandwitch;

public abstract class SandwitchDecorator extends Sandwitch {
    // decalration de l'objet sandwitch
    Sandwitch sandwitch;

    public SandwitchDecorator(Sandwitch sandwitch) {
        this.sandwitch = sandwitch;
    }
}
