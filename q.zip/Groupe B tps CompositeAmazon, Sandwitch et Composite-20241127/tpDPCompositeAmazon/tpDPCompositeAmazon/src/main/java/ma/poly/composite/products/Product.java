package ma.poly.composite.products;

import ma.poly.composite.Box;

public abstract class Product implements Box {
    protected String name;
    protected  double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
