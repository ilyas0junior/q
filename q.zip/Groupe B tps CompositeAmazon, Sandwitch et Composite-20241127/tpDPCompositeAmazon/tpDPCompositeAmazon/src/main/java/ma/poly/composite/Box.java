package ma.poly.composite;

public interface Box {
    public double calculatePrice();
}
